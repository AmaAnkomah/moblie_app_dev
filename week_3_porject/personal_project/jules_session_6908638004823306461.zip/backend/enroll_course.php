<?php
include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->user_id) && !empty($data->course_id)) {
    $user_id = $data->user_id;
    $course_id = $data->course_id;

    $query = "INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);

    try {
        if($stmt->execute([$user_id, $course_id])) {
            http_response_code(201);
            echo json_encode(["status" => "success", "message" => "Enrolled successfully."]);
        } else {
            http_response_code(503);
            echo json_encode(["status" => "error", "message" => "Unable to enroll."]);
        }
    } catch (PDOException $e) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Already enrolled or other error."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>
