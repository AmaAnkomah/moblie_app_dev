<?php
include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->email) && !empty($data->password)) {
    $email = $data->email;
    $password = $data->password;

    $query = "SELECT id, name, email, password, role FROM users WHERE email = ? LIMIT 0,1";
    $stmt = $conn->prepare($query);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user && password_verify($password, $user['password'])) {
        unset($user['password']); // Don't return password
        http_response_code(200);
        echo json_encode(["status" => "success", "user" => $user]);
    } else {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Login failed."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>
