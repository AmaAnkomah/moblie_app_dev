<?php
include_once 'db_connect.php';

$query = "SELECT c.id, c.title, c.description, c.price, c.thumbnail, u.name as instructor_name 
          FROM courses c 
          JOIN users u ON c.instructor_id = u.id 
          ORDER BY c.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

http_response_code(200);
echo json_encode(["status" => "success", "courses" => $courses]);
?>
