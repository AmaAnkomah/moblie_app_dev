<?php
include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->name) && !empty($data->email) && !empty($data->password)) {
    $name = $data->name;
    $email = $data->email;
    $password = password_hash($data->password, PASSWORD_DEFAULT);
    $role = !empty($data->role) ? $data->role : 'student';

    $query = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    try {
        if($stmt->execute([$name, $email, $password, $role])) {
            http_response_code(201);
            echo json_encode(["status" => "success", "message" => "User was created."]);
        } else {
            http_response_code(503);
            echo json_encode(["status" => "error", "message" => "Unable to create user."]);
        }
    } catch (PDOException $e) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Email already exists or other error."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>
