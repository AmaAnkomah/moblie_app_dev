<?php
include_once 'db_connect.php';

$course_id = isset($_GET['id']) ? $_GET['id'] : die();

$query = "SELECT c.*, u.name as instructor_name FROM courses c JOIN users u ON c.instructor_id = u.id WHERE c.id = ?";
$stmt = $conn->prepare($query);
$stmt->execute([$course_id]);
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if($course) {
    $lesson_query = "SELECT * FROM lessons WHERE course_id = ? ORDER BY `order` ASC";
    $lesson_stmt = $conn->prepare($lesson_query);
    $lesson_stmt->execute([$course_id]);
    $lessons = $lesson_stmt->fetchAll(PDO::FETCH_ASSOC);
    $course['lessons'] = $lessons;

    http_response_code(200);
    echo json_encode(["status" => "success", "course" => $course]);
} else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Course not found."]);
}
?>
