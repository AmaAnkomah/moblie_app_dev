<?php
include_once 'db_connect.php';

$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : die();

$query = "SELECT c.id, c.title, c.description, c.thumbnail, u.name as instructor_name 
          FROM enrollments e 
          JOIN courses c ON e.course_id = c.id 
          JOIN users u ON c.instructor_id = u.id 
          WHERE e.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->execute([$user_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

http_response_code(200);
echo json_encode(["status" => "success", "courses" => $courses]);
?>
