USE online_course_db;

-- Sample Users
INSERT INTO users (name, email, password, role) VALUES 
('Alice Instructor', 'alice@example.com', 'password123', 'instructor'),
('Bob Student', 'bob@example.com', 'password123', 'student');

-- Sample Courses
INSERT INTO courses (title, description, instructor_id, price, thumbnail) VALUES 
('Introduction to Flutter', 'Learn Flutter from scratch', 1, 49.99, 'https://example.com/flutter.png'),
('Advanced PHP', 'Master PHP development', 1, 59.99, 'https://example.com/php.png');

-- Sample Lessons
INSERT INTO lessons (course_id, title, content, video_url, `order`) VALUES 
(1, 'Course Introduction', 'Welcome to the course', 'https://example.com/intro.mp4', 1),
(1, 'Setup Flutter Environment', 'Learn how to setup Flutter', 'https://example.com/setup.mp4', 2),
(2, 'Composer Basics', 'How to use composer', 'https://example.com/composer.mp4', 1);
